var GEMINI_API_KEY = API_Key; // Supply your Google AI Studio API key

async function Send(prompt) { // Send prompt to Google Gemini API
    try {
        const endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + encodeURIComponent(GEMINI_API_KEY);
        const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [
                    { role: 'user', parts: [{ text: String(prompt) }]} 
                ]
            })
        });

        if (!res.ok) {
            throw new Error('Gemini API error: ' + res.status + ' ' + res.statusText);
        }

        const data = await res.json();
        const s = (data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0].text) || 'Brak odpowiedzi';

        $('#mssg').append("<div class='direct-chat-msg'><div class='direct-chat-infos clearfix'><span class='direct-chat-name float-left'>Bocik</span><span class='direct-chat-timestamp float-right'><a href='#' vall='" + s.replace(/'/g, "&#39;") + "' class='text-primary play'><i class='fas fa-play-circle'></i></a></span></div><img class='direct-chat-img' src='img/neo.jpg' alt='Message User Image'><div class='direct-chat-text'>" + s + "</div> </div>");
        if (typeof SpeakIfEnabled === 'function') { SpeakIfEnabled(s); }
        $('#Ask').html("Wyślij");
        $('#Ask').prop('disabled', false);
        // Scroll to the answer
        $('#mssg').stop().animate({ scrollTop: $('#mssg')[0].scrollHeight }, 800);
        // Save in hidden to export CSV
        let cssv = s.replace(/(\r\n|\n|\r)/gm, ' ');
        let hddnn = $('#hdn_csv').val();
        $('#hdn_csv').val((hddnn || '') + '\r\nYou: ' + prompt + '\r\n Gemini: ' + cssv);
    } catch (err) {
        console.error(err);
        const s = 'Error: ' + (err && err.message ? err.message : 'Unexpected error');
        $('#mssg').append("<div class='direct-chat-msg'><div class='direct-chat-infos clearfix'><span class='direct-chat-name float-left'>Bocik</span></div><img class='direct-chat-img' src='img/neo.jpg' alt='Message User Image'><div class='direct-chat-text text-danger'>" + s + "</div> </div>");
        $('#Ask').html("Wyślij");
        $('#Ask').prop('disabled', false);
        $('#mssg').stop().animate({ scrollTop: $('#mssg')[0].scrollHeight }, 800);
    }
}

  $(function () {
  $('#export').click(function(){//Export Chat in CSV format
  downloadCSV("geminiExport.csv",$('#hdn_csv').val());
  });
  })
        function downloadCSV(filename, content) {
  // It works on all HTML5 Ready browsers as it uses the download attribute of the <a> element:
  const element = document.createElement('a');
  
  //A blob is a data type that can store binary data
  // "type" is a MIME type
  // It can have a different value, based on a file you want to save
  const blob = new Blob([content], { type: 'plain/text' });

  //createObjectURL() static method creates a DOMString containing a URL representing the object given in the parameter.
  const fileUrl = URL.createObjectURL(blob);

  //setAttribute() Sets the value of an attribute on the specified element.
  element.setAttribute('href', fileUrl); //file location
  element.setAttribute('download', filename); // file name
  element.style.display = 'none';

  //use appendChild() method to move an element from one element to another
  document.body.appendChild(element);
  element.click();

  //The removeChild() method of the Node interface removes a child node from the DOM and returns the removed node
  document.body.removeChild(element);
};
      
   function downloadFile(filename, content) {
  // It works on all HTML5 Ready browsers as it uses the download attribute of the <a> element:
  const element = document.createElement('a');

  //A blob is a data type that can store binary data
  // "type" is a MIME type
  // It can have a different value, based on a file you want to save
  const blob = new Blob([content], { type: 'plain/text' });

  //createObjectURL() static method creates a DOMString containing a URL representing the object given in the parameter.
  const fileUrl = URL.createObjectURL(blob);

  //setAttribute() Sets the value of an attribute on the specified element.
  element.setAttribute('href', fileUrl); //file location
  element.setAttribute('download', filename); // file name
  element.style.display = 'none';

  //use appendChild() method to move an element from one element to another
  document.body.appendChild(element);
  element.click();

  //The removeChild() method of the Node interface removes a child node from the DOM and returns the removed node
  document.body.removeChild(element);
};
//Clear chat
     $(document).ready(function(){
    $('#clear').click(function(){//Clear Chat
    let text = "Do you want to clear chat?";
  if (confirm(text) == true) {
 var theDiv = document.getElementById("mssg");
theDiv.innerHTML="";
  }
});
});
